export interface Inferred {
  pr?: number
  before?: string
  after?: string
  [key: string]: string | number | undefined
}
