export interface ActionError {
  error: string
  from: string
  message: string
  payload: string
}
