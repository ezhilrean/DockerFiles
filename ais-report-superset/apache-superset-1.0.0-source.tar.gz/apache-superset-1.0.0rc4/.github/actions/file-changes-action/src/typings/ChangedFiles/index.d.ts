export interface ChangedFiles {
  [key: string]: string[]
}
