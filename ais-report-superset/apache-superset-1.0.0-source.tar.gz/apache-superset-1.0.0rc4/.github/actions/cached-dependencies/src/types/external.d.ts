declare module '@actions/cache/dist/restore';
declare module '@actions/cache/dist/save';
