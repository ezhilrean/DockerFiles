import { run } from './setup';

run();
