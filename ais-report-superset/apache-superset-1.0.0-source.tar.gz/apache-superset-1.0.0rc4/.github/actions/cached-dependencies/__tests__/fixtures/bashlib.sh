#!/bin/bash

default-setup-command() {
  print-cachescript-path
}
